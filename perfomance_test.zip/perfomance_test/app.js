import express from 'express'
import fs from 'fs'
const app = express();
import JSONStream from 'JSONStream'


//reads json data efficiently
const filePath = './book.json';
const stream = fs.createReadStream(filePath, { encoding: 'utf8' });
const parser = JSONStream.parse('*');

stream.pipe(parser);

parser.on('data', jsonData => {

});

parser.on('error', error => {
    console.error('Error parsing the JSON data:', error);
});

parser.on('end', () => {
    console.log('JSON data ');

})



//filter the data


const fiPath = './book.json';
const streem = fs.createReadStream(fiPath, { encoding: 'utf8' });
const parserr = JSONStream.parse('*');

streem.pipe(parserr);

parser.on('data', jsonData => {
    // Filter based on genre given 
    if (jsonData.genre === 'fun') {
        //handles the filtered JSON data
        console.log(jsonData);
    }
});

parser.on('error', error => {
    console.error('Error parsing the JSON data:', error);
});

parser.on('end', () => {
    console.log('Data filtered successifuly');
});


//sort the filtered books in descending order



const location = './book.json';
const data_pass = fs.createReadStream(filePath, { encoding: 'utf8' });
const paser = JSONStream.parse('*');

data_pass.pipe(paser);

const filteredBook = [];

parser.on('data', jsonData => {
    // Filter based on genre
    if (jsonData.genre === 'fun') {
        filteredBook.push(jsonData);
    }
});

parser.on('error', error => {
    console.error('Error parsing the JSON data:', error);
});

parser.on('end', () => {
    // Sort the filtered books by published date in descending order
    const sortedBooks = filteredBook.sort((a, b) => new Date(b.published_date) - new Date(a.published_date));

    // Process the sorted books as needed
    console.log(sortedBooks);

    console.log('data has been sorted successifully');
});


app.listen(3005, () => {
    console.log("Congratulations! server is now working")
})